# StreamX Media3 Pro — Advanced Source Project

## Included in this revision
- Original dark glass / cyan player layout retained and extended for Android TV and touch devices.
- Multiple separately named M3U and Xtream profiles with profile switching and deletion.
- Xtream credentials and saved playlist profiles stored with AndroidX EncryptedSharedPreferences.
- M3U URL and local document import (local M3U content is saved as a named profile).
- M3U metadata parsing for channel names, group/category, tvg-logo and tvg-id.
- Channel logo display in the on-screen channel banner (Glide image loader).
- Search by channel name/category and category filter.
- Favorites and recent channel lists, persisted locally.
- XMLTV EPG URL import with current/next programme display when tvg-id / epg_channel_id matches XMLTV channel IDs.
- Media3 playback with HLS/DASH/RTSP modules, increased live buffer and one bounded retry on stream failure.
- TV remote DPAD/channel-up/down/number-key navigation plus on-screen mobile controls.
- Sleep timer, aspect-ratio modes and channel zapping OSD.
- Launcher icon resources and Android TV launcher intent.

## EPG
Tap the **EPG** button and enter an XMLTV guide URL supplied by your legitimate IPTV provider. XMLTV channel IDs should match the playlist's `tvg-id` (M3U) or `epg_channel_id` (Xtream) values. Not all providers expose matching IDs or XMLTV feeds.

## Build
1. Open this project in Android Studio.
2. Allow Gradle sync; install Android SDK Platform 34 and JDK 17 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

This archive is Android Studio source code, not a prebuilt APK. A Gradle/Android SDK build environment was not available during preparation, so successful compilation, runtime playback, and device compatibility have **not** been verified here. Test on an Android TV and phone before distributing.

## Security and lawful use
Only add playlist URLs, EPG feeds, and Xtream credentials that you are authorized to use. Credentials are encrypted at rest using AndroidX Security Crypto. Network cleartext is permitted because some IPTV providers still use HTTP; prefer HTTPS whenever the provider supports it.
