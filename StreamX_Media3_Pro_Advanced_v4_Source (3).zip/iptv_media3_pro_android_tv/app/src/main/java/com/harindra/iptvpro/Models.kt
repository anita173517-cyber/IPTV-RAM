package com.harindra.iptvpro

/**
 * Ultra-lean Channel model for <=512 MB RAM Android Smart TVs.
 * Unused per-instance default strings removed to save ~1.44 MB across 60,000 channels.
 */
data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val category: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val epgId: String = ""
) {
    companion object {
        const val DEFAULT_PROGRAM = "Live Broadcast"
        const val DEFAULT_NEXT_PROGRAM = "Upcoming Show"
    }
}

data class XtreamCredentials(
    val profileName: String,
    val serverUrl: String,
    val username: String,
    val password: String
)
