package com.harindra.iptvpro

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.coroutines.coroutineContext

class ChannelCacheStore(context: Context) {
    private val appContext = context.applicationContext
    private val cacheMutex = Mutex()

    companion object {
        private const val CACHE_PREFIX = "streamx_channel_cache_"
        private const val MAX_CACHE_FILES = 3
        private const val MAX_TOTAL_CACHE_BYTES = 16L * 1024L * 1024L // 16 MB bound for old Smart TVs
        private const val MAX_CACHED_CHANNELS = 60_000
        const val PLAYLIST_REFRESH_TTL_MS = 6L * 60L * 60L * 1000L // 6 hours background refresh TTL
    }

    init {
        // Clean up any orphaned .tmp files from interrupted imports
        runCatching {
            appContext.filesDir.listFiles()?.forEach { f ->
                if (f.name.endsWith(".tmp")) f.delete()
            }
        }
    }

    private fun cacheFileFor(key: String): File {
        val safeKey = key.replace(Regex("[^a-zA-Z0-9_.-]"), "_").take(64).ifBlank { "default" }
        return File(appContext.filesDir, "$CACHE_PREFIX$safeKey.json")
    }

    fun isCacheStale(key: String, ttlMs: Long = PLAYLIST_REFRESH_TTL_MS): Boolean {
        val f = cacheFileFor(key)
        if (!f.exists() || f.length() <= 2L) return true
        return (System.currentTimeMillis() - f.lastModified()) > ttlMs
    }

    suspend fun saveChannels(key: String, channels: List<Channel>, maxLimit: Int = MAX_CACHED_CHANNELS) = withContext(Dispatchers.IO) {
        if (channels.isEmpty()) return@withContext
        cacheMutex.withLock {
            val targetFile = cacheFileFor(key)
            val tempFile = File(appContext.filesDir, "${targetFile.name}.tmp")
            try {
                FileOutputStream(tempFile).use { fos ->
                    JsonWriter(BufferedWriter(OutputStreamWriter(fos, Charsets.UTF_8), 16384)).use { writer ->
                        writer.beginArray()
                        val count = channels.size.coerceAtMost(maxLimit)
                        for (idx in 0 until count) {
                            if (idx % 1000 == 0) coroutineContext.ensureActive()
                            val ch = channels[idx]
                            writer.beginObject()
                            writer.name("i").value(ch.id)
                            writer.name("n").value(ch.number)
                            writer.name("t").value(ch.name)
                            writer.name("c").value(ch.category)
                            writer.name("u").value(ch.streamUrl)
                            if (ch.logoUrl.isNotEmpty()) writer.name("l").value(ch.logoUrl)
                            if (ch.epgId.isNotEmpty()) writer.name("e").value(ch.epgId)
                            writer.endObject()
                        }
                        writer.endArray()
                        writer.flush()
                    }
                    runCatching { fos.fd.sync() }
                }
                if (tempFile.exists() && tempFile.length() > 2L) {
                    if (targetFile.exists()) targetFile.delete()
                    if (!tempFile.renameTo(targetFile)) {
                        tempFile.copyTo(targetFile, overwrite = true)
                        tempFile.delete()
                    }
                    enforceCacheBounds(keepFile = targetFile)
                } else {
                    tempFile.delete()
                }
            } catch (e: Exception) {
                tempFile.delete()
                Log.w("StreamX", "Cache write aborted or failed for $key", e)
            }
        }
    }

    suspend fun loadChannels(
        key: String,
        maxLimit: Int = MAX_CACHED_CHANNELS,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)? = null
    ): List<Channel> = withContext(Dispatchers.IO) {
        cacheMutex.withLock {
            val file = cacheFileFor(key)
            if (!file.exists() || file.length() <= 2L) return@withLock emptyList()
            try {
                val result = ArrayList<Channel>(2048)
                val categoryPool = HashMap<String, String>(128)
                var firstBatchDispatched = false

                JsonReader(BufferedReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8), 16384)).use { reader ->
                    if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                        Log.w("StreamX", "Invalid cache header in ${file.name}; deleting corrupted cache")
                        file.delete()
                        return@withLock emptyList()
                    }
                    reader.beginArray()
                    var idx = 0
                    while (reader.hasNext() && idx < maxLimit) {
                        if (idx % 1000 == 0) coroutineContext.ensureActive()
                        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                            reader.skipValue()
                            continue
                        }
                        idx++
                        var id = ""
                        var num = idx
                        var name = ""
                        var category = "Live TV"
                        var streamUrl = ""
                        var logoUrl = ""
                        var epgId = ""

                        reader.beginObject()
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "i" -> id = readStr(reader)
                                "n" -> num = readInt(reader, idx)
                                "t" -> name = readStr(reader)
                                "c" -> {
                                    val rawCat = readStr(reader, "Live TV").ifBlank { "Live TV" }
                                    category = categoryPool.getOrPut(rawCat) { rawCat }
                                }
                                "u" -> streamUrl = readStr(reader)
                                "l" -> logoUrl = readStr(reader)
                                "e" -> epgId = readStr(reader)
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()

                        if (streamUrl.isNotEmpty()) {
                            result.add(
                                Channel(
                                    id = id.ifBlank { "ch_$idx" },
                                    number = if (num > 0) num else idx,
                                    name = name.ifBlank { "Channel $idx" },
                                    category = category,
                                    streamUrl = streamUrl,
                                    logoUrl = logoUrl,
                                    epgId = epgId
                                )
                            )
                            if (!firstBatchDispatched && result.size == 300 && onFirstBatchReady != null) {
                                firstBatchDispatched = true
                                onFirstBatchReady.invoke(ArrayList(result))
                            }
                        }
                    }
                    while (reader.hasNext()) {
                        reader.skipValue()
                    }
                    reader.endArray()
                }
                result
            } catch (e: Exception) {
                Log.w("StreamX", "Corrupted or cancelled cache read for ${file.name}; removing file", e)
                runCatching { file.delete() }
                emptyList()
            }
        }
    }

    fun totalCacheSizeBytes(): Long {
        return try {
            appContext.filesDir.listFiles { f ->
                f.isFile && f.name.startsWith(CACHE_PREFIX) && f.name.endsWith(".json")
            }?.sumOf { it.length() } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun enforceCacheBounds(keepFile: File) {
        try {
            val files = appContext.filesDir.listFiles { f ->
                f.isFile && f.name.startsWith(CACHE_PREFIX) && f.name.endsWith(".json")
            }?.sortedByDescending { it.lastModified() } ?: return

            var totalBytes = 0L
            files.forEachIndexed { index, f ->
                totalBytes += f.length()
                if (f != keepFile && (index >= MAX_CACHE_FILES || totalBytes > MAX_TOTAL_CACHE_BYTES)) {
                    f.delete()
                }
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to enforce cache bounds", e)
        }
    }

    suspend fun clearCache(key: String) = withContext(Dispatchers.IO) {
        cacheMutex.withLock {
            runCatching {
                val file = cacheFileFor(key)
                if (file.exists()) file.delete()
            }
        }
    }

    suspend fun clearAllCaches() = withContext(Dispatchers.IO) {
        cacheMutex.withLock {
            runCatching {
                appContext.filesDir.listFiles()?.forEach { f ->
                    if (f.name.startsWith(CACHE_PREFIX) || f.name.endsWith(".tmp")) {
                        f.delete()
                    }
                }
            }
        }
    }

    private fun readStr(reader: JsonReader, default: String = ""): String {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.STRING, JsonToken.NUMBER -> reader.nextString()
            JsonToken.BOOLEAN -> reader.nextBoolean().toString()
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readInt(reader: JsonReader, default: Int): Int {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextInt() }.getOrElse {
                runCatching { reader.nextString().toIntOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toIntOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }
}
